package com.example.calc;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MyActivity extends Activity {
    /**
     * Called when the activity is first created.
     */
    Button b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, bdot, clr, bck, plus, minus, divide, multi, equal;
    TextView et;
    String s1, s2;
    int i;
    float val1, val2;
    boolean add, sub, mult, div, rms;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        et = (TextView) findViewById(R.id.output);
        b0 = (Button) findViewById(R.id.but0);
        b1 = (Button) findViewById(R.id.but1);
        b2 = (Button) findViewById(R.id.but2);
        b3 = (Button) findViewById(R.id.but3);
        b4 = (Button) findViewById(R.id.but4);
        b5 = (Button) findViewById(R.id.but5);
        b6 = (Button) findViewById(R.id.but6);
        b7 = (Button) findViewById(R.id.but7);
        b8 = (Button) findViewById(R.id.but8);
        b9 = (Button) findViewById(R.id.but9);
        bdot = (Button) findViewById(R.id.butdot);
        clr = (Button) findViewById(R.id.butclr);
        bck = (Button) findViewById(R.id.butbcksp);
        plus = (Button) findViewById(R.id.butplus);
        minus = (Button) findViewById(R.id.butminus);
        divide = (Button) findViewById(R.id.butdiv);
        multi = (Button) findViewById(R.id.butmulti);
        equal = (Button) findViewById(R.id.butequal);

        b0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                et.setText(et.getText() + "0");
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                et.setText(et.getText() + "1");
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                et.setText(et.getText() + "2");
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                et.setText(et.getText() + "3");
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                et.setText(et.getText() + "4");
            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                et.setText(et.getText() + "5");
            }
        });
        b6.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                et.setText(et.getText() + "6");
            }
        });
        b7.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                et.setText(et.getText() + "7");
            }
        });
        b8.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                et.setText(et.getText() + "8");
            }
        });
        b9.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                et.setText(et.getText() + "9");
            }
        });
        b0.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                et.setText(et.getText() + "0");
            }
        });
        bdot.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                et.setText(et.getText() + ".");
            }
        });
        clr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                et.setText("");
            }
        });
        bck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                s1 = et.getText().toString();
                i = s1.length();
                s2 = s1.substring(0, i - 1);
                et.setText(s2);
            }
        });
        plus.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                val1 = Float.parseFloat(et.getText() + "");
                add = true;
                et.setText(null);
            }
        });

        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                val1 = Float.parseFloat(et.getText() + "");
                sub = true;
                et.setText(null);
            }
        });

        divide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                val1 = Float.parseFloat(et.getText() + "");
                div = true;
                et.setText(null);
            }
        });

        multi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                val1 = Float.parseFloat(et.getText() + "");
                mult = true;
                et.setText(null);
            }
        });

        equal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                val2 = Float.parseFloat(et.getText() + "");
                if (add == true) {
                    et.setText(val1 + val2 + "");
                    add = false;
                }
                if (sub == true) {
                    et.setText(val1 - val2 + "");
                    sub = false;
                }
                if (mult == true) {
                    et.setText(val1 * val2 + "");
                    mult = false;

                }
                if (div == true) {
                    et.setText(val1 / val2 + "");
                    div = false;
                }
                if (rms == true) {
                    et.setText(val1 % val2 + "");
                    rms = false;
                }
            }
        });
    }
}


