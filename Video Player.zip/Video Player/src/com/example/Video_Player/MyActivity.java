package com.example.Video_Player;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.Toast;

public class MyActivity extends Activity implements SurfaceHolder.Callback {

    SurfaceHolder sv;
    SurfaceView s1;
    MediaPlayer mp;
    ImageButton b1,b2,b3,b4,b5;
    SeekBar sb;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        s1=(SurfaceView)findViewById(R.id.surfaceView);
        mp=new MediaPlayer();

        b1=(ImageButton)findViewById(R.id.previous);
        b2=(ImageButton)findViewById(R.id.pause);
        b3=(ImageButton)findViewById(R.id.play);
        b4=(ImageButton)findViewById(R.id.stop);
        b5=(ImageButton)findViewById(R.id.next);
        sb=(SeekBar)findViewById(R.id.seekBar);

       sv=s1.getHolder();
       sv.addCallback(this);
    }

    @Override
    public void surfaceCreated(SurfaceHolder surfaceHolder) {
        mp.setDisplay(surfaceHolder);
        try
        {
            mp.setDataSource("/storage/sdcard/airtel.mp4");
            mp.prepare();
            mp.seekTo(1);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            Toast.makeText(this.getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
        }

    }

    @Override
    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {

    }
    public void play(View v)
    {
        Toast.makeText(this.getApplicationContext(),"Playing...",Toast.LENGTH_LONG).show();
        mp.start();
    }

    public void pause(View v)
    {
        Toast.makeText(this.getApplicationContext(),"Paused",Toast.LENGTH_LONG).show();
        mp.pause();
    }
    public void stop(View v)
    {
        mp.stop();
        mp.reset();
        Toast.makeText(this.getApplicationContext(),"Stopped",Toast.LENGTH_LONG).show();
        try {
            mp.setDataSource("/storage/sdcard/airtel.mp4");
            mp.prepare();
        }
        catch(Exception e){ e.printStackTrace();}
    }
}
