package com.example.KidS_StorieS;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Created by android on 2/11/16.
 */
public class story extends Activity {



    String Strstory;
    TextView tv;
    StringBuilder sr;
    SharedPreferences sp;
    float i=15;
    SharedPreferences.Editor e;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.story);



        InputStream f=this.getResources().openRawResource(R.raw.story3);
        InputStreamReader isr=new InputStreamReader(f);
        BufferedReader bufferedReader=new BufferedReader(isr);
        tv=(TextView)findViewById(R.id.textView3);
        sr=new StringBuilder();

        try {
            while((Strstory=bufferedReader.readLine())!=null)
            {

                sr.append(Strstory);
                sr.append("\n");
                tv.setText(sr);

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        sp=getSharedPreferences("story2", Context.MODE_PRIVATE);
        i=sp.getFloat("size", 15);
        tv.setTextSize(i);
        e=sp.edit();

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater=getMenuInflater();
        menuInflater.inflate(R.menu.menu,menu);

        return true;
    }

    @Override
    public boolean onMenuItemSelected(int featureId, MenuItem item) {
        if(item.getItemId()==R.id.zoomin)
        {
            i++;
            e.putFloat("size",i);
            e.commit();
            e.apply();
            tv.setTextSize(i);

        }
        else
        {
            i--;
            e.putFloat("size",i);
            e.commit();
            e.apply();
            tv.setTextSize(i);

        }


        return super.onMenuItemSelected(featureId, item);
    }
}