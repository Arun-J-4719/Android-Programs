package com.example.KidS_StorieS;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by android on 21/10/16.
 */
public class Stories extends Activity {

    ListView l1;

    Intent in;
    String[] name={"The Cunning Wolf","The Everyone is Important","The Hotel Owners"};
    Integer[] imageid={R.drawable.img1,R.drawable.img2,R.drawable.img3,R.drawable.img4};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.stories);


        l1=(ListView)findViewById(R.id.listView);

        String[] story=getResources().getStringArray(R.array.story_name);
        ArrayAdapter ado=new ArrayAdapter(this,android.R.layout.simple_list_item_1,story);
        l1.setAdapter(ado);




        l1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i)
                {
                    case 0:
                        in=new Intent(getApplicationContext(),read.class);
                        break;
                    case 1:
                        in=new Intent(getApplicationContext(),story2.class);
                        break;
                    case 2:
                    in=new Intent(getApplicationContext(),story.class);
                    break;
                }
                startActivity(in);

            }
        });

    }
}