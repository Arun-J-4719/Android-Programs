package com.example.Story_App;

/**
 * Created by android on 21/10/16.
 */
public class My_Story {
    public String sn,sp;

    public My_Story() {
    }

    public My_Story(String , String sp) {
        this.
    }
}
