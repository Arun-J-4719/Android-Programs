package com.example.Story_App;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by android on 21/10/16.
 */
public class Story_List extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.story_list);
        Context c;
        ArrayList<My_Story> Story;

        public dispcontacts(Context c, ArrayList<My_Story> al)
        {
            this.c = c;
            this.alContacts = al;
        }

        @Override
        public int getCount() {
            return alContacts.size();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            View v = android.view.View.inflate(c, R.layout.dispcontacts, null);

            ImageView iv = (ImageView)v.findViewById(R.id.imgContact);
            TextView txtName = (TextView)v.findViewById(R.id.nmeid);
            TextView txtPhone = (TextView)v.findViewById(R.id.phnid);

            iv.setImageResource(R.drawable.ic_launcher);
            txtName.setText(alContacts.get(i).sn);
            txtPhone.setText(alContacts.get(i).sp);

            return v;
        }

    }
}