package com.example.Gallery;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

/**
 * Created by android on 7/10/16.
 */
public class image extends Activity {
    public Integer[] image = {
            R.drawable.image1,
            R.drawable.image2,
            R.drawable.image3,
            R.drawable.image4,
            R.drawable.image5,
            R.drawable.image6,
            R.drawable.image7,
            R.drawable.image8,
    };
    int x;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.preview);
        Bundle b=getIntent().getExtras();
        x=b.getInt("Index");
        ImageView im=(ImageView)findViewById(R.id.imageView2);
        im.setImageResource(image[x]);
    }
    public void Home(View view){
        Intent intent = new Intent(getApplicationContext(),MyActivity.class);
        startActivity(intent);
    }
    public void prev(View view){
        ImageView im=(ImageView)findViewById(R.id.imageView2);
        if(x==0)
        {
           im.setImageResource(image[7]);
            x=7;
        }
        else
        {
            x = x - 1;
            im.setImageResource(image[x]);
        }
    }
    public void next(View view){
        ImageView im=(ImageView)findViewById(R.id.imageView2);
        if(x==7)
        {
            im.setImageResource(image[0]);
            x=0;
        }
        else
         {
             x=x+1;
             im.setImageResource(image[x]);
         }
    }

}