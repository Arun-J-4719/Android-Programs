package com.example.Gallery;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

/**
 * Created by android on 13/8/16.
 */
public class ImageAdo extends BaseAdapter{
    Context con;

    public ImageAdo(Context con)
    {

        this.con = con;
    }

    @Override
    public int getCount() {

        return image.length;
    }

    @Override
    public Object getItem(int i) {

        return image[i];
    }

    @Override
    public long getItemId(int i) {

        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ImageView iv=new ImageView(con);
        iv.setLayoutParams(new GridView.LayoutParams(400, 400));
        iv.setScaleType(ImageView.ScaleType.FIT_XY);
        iv.setPadding(8, 8, 8, 8);
        iv.setImageResource(image[i]);
        return iv;
    }
    public Integer[] image = {
            R.drawable.image1,
            R.drawable.image2,
            R.drawable.image3,
            R.drawable.image4,
            R.drawable.image5,
            R.drawable.image6,
            R.drawable.image7,
            R.drawable.image8,
    };
}

