package com.example.Gallery;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

public class MyActivity extends Activity {
    /**
     * Called when the activity is first created.
     */

   // int[] image={R.drawable.ic_launcher};
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        GridView g;
        g=(GridView)findViewById(R.id.gridView);
        g.setAdapter(new ImageAdo(this));
        g.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(),image.class);
                intent.putExtra("Index",i);
                startActivity(intent);
            }
        });
    }
}



