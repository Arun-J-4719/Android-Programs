package com.example.Web_View;

import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Created by android on 15/10/16.
 */
public class Web extends WebViewClient {
    @Override
    public boolean shouldOverrideUrlLoading(WebView view, String url) {
        return (false);
    }
}