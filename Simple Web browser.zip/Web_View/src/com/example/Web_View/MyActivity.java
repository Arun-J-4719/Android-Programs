package com.example.Web_View;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.AutoCompleteTextView;
import android.widget.ImageButton;
import android.widget.Toast;

public class MyActivity extends Activity {
    /**
     * Called when the activity is first created.
     */
WebView wv;
AutoCompleteTextView actv;
ImageButton imgbtn;
String url;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState);
        setContentView(R.layout.main);
        Web web=new Web();
        wv = (WebView) findViewById(R.id.webView);
        wv.setWebViewClient(web);
        actv=(AutoCompleteTextView)findViewById(R.id.autoCompleteTextView);
        imgbtn=(ImageButton)findViewById(R.id.srch_button);
        wv.loadUrl("http://www.w3schools.com");
        wv.setWebChromeClient(new WebChromeClient() {
            public void onProgressChanged(WebView view, int progress) {

                setTitle("Loading...");
                setProgress(progress * 100);
                if (progress == 100)
                {
                    setTitle(wv.getTitle());
                }
            }
        });
    }
    public void search(View view)
    {
        url = actv.getText().toString();
        wv.loadUrl("http://www."+url);
        wv.getSettings().setJavaScriptEnabled(true);
    }
    public void forward(View view)
    {
        try
        {
            wv.goForward();
        }
        catch (Exception ex)
        {

            Toast.makeText(this,"This is the Last Page",Toast.LENGTH_LONG).show();
        }
    }
    public void backward(View view)
    {
        try
        {
            wv.goBack();
        }
        catch (Exception ex)
        {

            Toast.makeText(this,"This is the First Page",Toast.LENGTH_LONG).show();
        }
    }
    public void refresh(View view)
    {

        wv.reload();
    }
    public void wiki(View view)
    {
        wv.loadUrl("https://en.wikipedia.org");
    }
    public void linked(View view)
    {
        wv.loadUrl("www.linkedin.com");
    }
}
